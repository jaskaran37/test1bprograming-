package com.example.demo5;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label messageLabel;

    private int attempts = 0;
    private boolean accountLocked = false;

    @FXML
    protected void onLoginButtonClick() {
        if (accountLocked) {
            messageLabel.setText("Sorry, Your Account is Locked!!!");
            return;
        }

        String username = usernameField.getText();
        String password = passwordField.getText();

        if (username.isEmpty() || password.isEmpty()) {
            messageLabel.setText("Please Provide Username or Password.");
        } else {
            if (username.equals("jkrn") && password.equals("1234")) {
                messageLabel.setText("Success!!!");
            } else {
                attempts++;
                if (attempts >= 5) {
                    accountLocked = true;
                    messageLabel.setText("Sorry, Your Account is Locked!!!");
                } else {
                    messageLabel.setText("Sorry, Invalid Username or Password");
                }
            }
        }
    }
}
